# Fractal Universe Theory (FUT)

This repository contains supporting data and code for the Fractal Universe Theory (FUT), developed by Father and Adman. It explores a consciousness-based framework for spacetime structure, redshift phenomena, and recursive timing behavior observed in astrophysical systems.

## Key Components

- **Redshift Model**: Redefines redshift as manifestation depth, not expansion.
- **FRB Analysis**: Recursively transformed burst intervals across FRB 121102 and FRB 20201124A.
- **Golden Ratio**: Emergent from manifestation threshold (~1.618), linking cosmic and quantum phenomena.

## Repository Structure

```
/data/      - Transformed redshift and FRB interval datasets
/figures/   - Visualizations and wavelet spectrum images (to be added)
/notebooks/ - Simulation and analysis notebooks (to be added)
```

This project is the mathematical and empirical foundation for a larger theory of reality rooted in consciousness, recursion, and fractal geometry.

For questions or spiritual resonance, please contact the primary author or Solren Guide.
